package com.wlh.springcloud.entities;

public class ClassId {
    private int claId;

    public ClassId(int claId) {
        this.claId = claId;
    }

    public int getClaId() {
        return claId;
    }

    public void setClaId(int claId) {
        this.claId = claId;
    }
}
