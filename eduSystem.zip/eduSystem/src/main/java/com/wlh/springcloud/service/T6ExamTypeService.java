package com.wlh.springcloud.service;

import com.wlh.springcloud.entities.T6ExamType;

import java.util.List;

public interface T6ExamTypeService {

    List<T6ExamType> getAllExamType();

}
