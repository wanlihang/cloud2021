package com.wlh.springcloud.service;

public interface  T1TeacherService {

}
