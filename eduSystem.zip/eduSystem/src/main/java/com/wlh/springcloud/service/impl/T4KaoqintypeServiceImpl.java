package com.wlh.springcloud.service.impl;

import com.wlh.springcloud.service.T4KaoqintypeService;
import org.springframework.stereotype.Service;


@Service
public class T4KaoqintypeServiceImpl implements T4KaoqintypeService {

}
