package com.wlh.springcloud.service;

public interface T4KaoqintypeService {

}
